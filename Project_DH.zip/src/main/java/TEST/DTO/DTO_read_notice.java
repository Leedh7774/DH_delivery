package TEST.DTO;

import lombok.Data;

@Data
public class DTO_read_notice {
	private String user_id, old_title, old_writing, old_name;
}
