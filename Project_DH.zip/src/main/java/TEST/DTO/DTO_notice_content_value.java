package TEST.DTO;

import lombok.Data;

@Data
public class DTO_notice_content_value {
	private String  id, name, target_id, target_title, writing;
}
