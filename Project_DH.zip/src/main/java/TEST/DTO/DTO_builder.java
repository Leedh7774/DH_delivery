package TEST.DTO;

public class DTO_builder {
	private String id, pw, name, s_1, s_2, postcode, addr, detail_addr;

	public DTO_builder id(String id) {
		this.id = id;
		return this;
	}
	public DTO_builder pw(String pw) {
		this.pw = pw;
		return this;
	}
	public DTO_builder name(String name) {
		this.name = name;
		return this;
	}
	public DTO_builder s_1(String s_1) {
		this.s_1 = s_1;
		return this;
	}
	public DTO_builder s_2(String s_2) {
		this.s_2 = s_2;
		return this;
	}
	public DTO_builder postcode(String postcode) {
		this.postcode = postcode;
		return this;
	}
	public DTO_builder addr(String addr) {
		this.addr = addr;
		return this;
	}
	public DTO_builder detail_addr(String detail_addr) {
		this.detail_addr = detail_addr;
		return this;
	}
	public DTO_FieldValue builder() {
		return new DTO_FieldValue(id,pw,name,s_1,s_2,postcode,addr,detail_addr);
	}
}