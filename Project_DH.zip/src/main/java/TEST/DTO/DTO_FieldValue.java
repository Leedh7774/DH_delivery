package TEST.DTO;

import lombok.Getter;

@Getter
public class DTO_FieldValue {
	private String id, pw, name, s_1, s_2, postcode, addr, detail_addr;
	
	DTO_FieldValue(String id, String pw, String name, String s_1, String s_2, String postcode, String addr, String detail_addr){
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.s_1 = s_1;
		this.s_2 = s_2;
		this.postcode = postcode;
		this.addr = addr;
		this.detail_addr = detail_addr;
	}
	


}