package TEST.DTO;

import lombok.Data;

@Data
public class DTO_notice_value {
	private String id, name, title, writing;
	
}
