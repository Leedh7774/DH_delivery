package TEST.DTO;

import lombok.Data;

@Data
public class DTO_world_value {
	public String world;
}
