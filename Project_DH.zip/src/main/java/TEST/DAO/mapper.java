package TEST.DAO;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import TEST.DTO.DTO_FieldValue;
import TEST.DTO.DTO_food_value;
import TEST.DTO.DTO_notice_content_value;
import TEST.DTO.DTO_notice_value;
import TEST.DTO.DTO_world_value;

@Mapper
public interface mapper {
	@Insert("INSERT INTO USER_INFO VALUES(#{ID}, #{PW}, #{NAME}, #{S_1}, #{S_2}, #{POSTCODE}, #{ADDRESS}, #{DETAILADDRESS})")
	public void DB_Insert(String ID, String PW, String NAME, String S_1, String S_2, String POSTCODE, String ADDRESS, String DETAILADDRESS);
	
	@Select("Select * from USER_INFO")
	public List<DTO_FieldValue> DB_Select();
	
	@Insert("INSERT INTO NOTICE_BOARD VALUES(#{ID}, #{NAME}, #{TITLE}, #{WRITING})")
	public void DB_notice_Insert(String ID, String NAME, String TITLE, String WRITING);
	
	@Select("Select * from NOTICE_BOARD")
	public List<DTO_notice_value> DB_notice_Select();
	
	@Update("UPDATE NOTICE_BOARD SET TITLE=#{new_title}, WRITING=#{writing} WHERE ID=#{id} AND TITLE=#{old_title}")
	public void DB_notice_Update(String new_title, String writing, String id, String old_title);
	
	@Delete("DELETE FROM NOTICE_BOARD WHERE ID=#{id} AND TITLE=#{title}")
	public void DB_notice_Delete(String id, String title);
	
	@Select("SELECT * FROM NOTICE_CONTENT")
	public List<DTO_notice_content_value> DB_notice_content_Select();
	
	@Insert("INSERT INTO NOTICE_CONTENT VALUES(#{ID}, #{NAME}, #{TARGET_ID}, #{TARGET_TITLE}, #{WRITING})")
	public void DB_notice_content_Insert(String ID, String NAME, String TARGET_ID, String TARGET_TITLE, String WRITING);
	
	@Delete("DELETE FROM NOTICE_CONTENT WHERE ID=#{ID} AND WRITING=#{WRITING}")
	public void DB_notice_content_Delete(String ID, String WRITING);
	
	@Insert("INSERT INTO KOREAN_FOOD VALUES(#{FOOD})")
	public void DB_Korean_food_insert(String FOOD);
	@Insert("INSERT INTO CHINESE_FOOD VALUES(#{FOOD})")
	public void DB_Chinese_food_insert(String FOOD);
	@Insert("INSERT INTO JAPANESE_FOOD VALUES(#{FOOD})")
	public void DB_Japanese_food_insert(String FOOD);
	@Insert("INSERT INTO WESTERN_FOOD VALUES(#{FOOD})")
	public void DB_Western_food_insert(String FOOD);
	
	@Delete("DELETE FROM KOREAN_FOOD WHERE FOOD=#{FOOD}")
	public void DB_Korean_food_delete(String FOOD);
	@Delete("DELETE FROM CHINESE_FOOD WHERE FOOD=#{FOOD}")
	public void DB_Chinese_food_delete(String FOOD);
	@Delete("DELETE FROM JAPANESE_FOOD WHERE FOOD=#{FOOD}")
	public void DB_Japanese_food_delete(String FOOD);
	@Delete("DELETE FROM WESTERN_FOOD WHERE FOOD=#{FOOD}")
	public void DB_Western_food_delete(String FOOD);
	
	@Select("Select * from WORLD")
	public List<DTO_world_value> DB_WORLD_Select();
	@Select("Select * from KOREAN_FOOD")
	public List<DTO_food_value> DB_KOREAN_Select();
	@Select("Select * from CHINESE_FOOD")
	public List<DTO_food_value> DB_CHINESE_Select();
	@Select("Select * from JAPANESE_FOOD")
	public List<DTO_food_value> DB_JAPANESE_Select();
	@Select("Select * from WESTERN_FOOD")
	public List<DTO_food_value> DB_WESTERN_Select();
	
}
