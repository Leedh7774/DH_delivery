package TEST.Security_Cont;

import java.util.Collection;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import TEST.Controller.CS_cont;
import TEST.DAO.mapper;
import TEST.DTO.DTO_FieldValue;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Configuration
@EnableWebSecurity
@Controller
public class Secure_Config {
	InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
	@Autowired
	private mapper ma;
	

	@Bean
	public SecurityFilterChain Security(HttpSecurity http) throws Exception { //http Security
		
		http.authorizeHttpRequests(auth -> 
		auth.requestMatchers("/","/login/**","/img/**","/css/**").permitAll()
		.requestMatchers("/main/**","/logout/**").hasAnyRole("USER")
		.requestMatchers("/main/**","/logout/**","/admin/**").hasAnyRole("ADMIN")
		.anyRequest().authenticated());
		
		http.csrf().disable();
		
		http.formLogin(login -> 
		login.loginPage("/login").defaultSuccessUrl("/first_login").permitAll());
		// 커스텀 로그인창         // 로그인 성공 시 위치   
		
		http.logout().logoutUrl("/logout") // 로그아웃 URL 설정
		.logoutSuccessUrl("/") // 로그아웃 성공 후 이동할 URL 설정
		.invalidateHttpSession(true) // HTTP 세션 무효화 여부 설정
		.deleteCookies("JSESSIONID") // 로그아웃 시 삭제할 쿠키 설정
		.deleteCookies("Cookies");
		
		return http.build();
	}
	
	//logout
	@RequestMapping("/logout")
	public void sec_logout() {
	}
	
	@RequestMapping("/login/success")
	public String join_success(){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		if(auth == null) {
			return "/login/Before_login.html";
		}
		
		sec_logout();
		return "/login/Before_login.html";
	}
	
	
	@Bean
	public PasswordEncoder passwordEncoder() {
	    return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}

	@Bean
	public UserDetailsService DB_add_config() {
		    Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		    while(it.hasNext())
			{
				DTO_FieldValue d_val = it.next();
				UserDetails DB_user = User.withUsername(d_val.getId())
						.password(passwordEncoder().encode(d_val.getPw()))
				        .roles("USER")
				        .build();
				manager.createUser(DB_user);
			}	
		    UserDetails DB_user = User.withUsername("adminDH") //admin 계정 등록
					.password(passwordEncoder().encode("1234"))
			        .roles("ADMIN")
			        .build();
			manager.createUser(DB_user);
		    return manager;
		  }
	
	@PostMapping("/login/DB_insert") //Database insert 구문
	public String join_page(@RequestParam(name="permit_id") String id,
		      @RequestParam(name="PW") String pw,
		      @RequestParam(name="NAME") String name,
		      @RequestParam(name="S_N1") String s_n1,
		      @RequestParam(name="S_N2") String s_n2,
		      @RequestParam(name="POSTCODE") String postcode,
		      @RequestParam(name="ADDR") String addr,
		      @RequestParam(name="DETAIL_ADDR") String detail_addr) {
		
		ma.DB_Insert(id, pw, name, s_n1, s_n2, postcode, addr, detail_addr); //Database 적재
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		
		while(it.hasNext())
		{
			DTO_FieldValue d_val = it.next();
			if(it.hasNext() != true)
			{
				UserDetails DB_user = User.withUsername(d_val.getId())
				        .password(passwordEncoder().encode(d_val.getPw()))
				        .roles("USER")
				        .build();
				manager.createUser(DB_user);
				break;
			}
		}	
		return "/login/Success_join.html";
	}
	
	@RequestMapping("/first_login")
	public String first_login(HttpServletRequest Http_request, HttpServletResponse Http_response, Model mo){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		
		int admin_key = 0;
		String user = auth.getName();
		
		Collection<? extends GrantedAuthority> roles = auth.getAuthorities(); // 현재 사용자의 rule 확인
		for (GrantedAuthority role : roles) {
		    if (role.getAuthority().equals("ROLE_ADMIN")) {
		    	mo.addAttribute("user", "관리자");
		        admin_key=1;
		        break; 
		    }
		}
		
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(user)) {
				mo.addAttribute("user", d_val.getName());
				mo.addAttribute("user_id", d_val.getId());
			}
		}
		
		HttpSession Http_Session = Http_request.getSession(false);
		if(Http_Session != null) {
			String Session_value = (String) Http_Session.getAttribute("Session");
			Cookie coo = new Cookie("Cookies", Session_value); // 쿠키 만들기
			coo.setPath("/");  
			coo.setMaxAge(1800); // 쿠키 소유 시간 : 30분
			Http_response.addCookie(coo); // 서버에 쿠키를 추가
		}
		
		mo.addAttribute("admin_key", admin_key);
		
		return "User/main.html";
	}
	
	@RequestMapping("/main")
	public String login_page(Model mo){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
			}
		}
		return "/User/main.html";
	}
	
	@RequestMapping("/")
	public String Before_login(HttpServletRequest Http_request, Model mo){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		CS_cont cs = new CS_cont();
		
		if(cs.Compare_Cookie_Session(Http_request)) {
			Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
			while(it.hasNext()) {
				DTO_FieldValue d_val = it.next();
				if(d_val.getId().equals(auth.getName())) {
					mo.addAttribute("user", d_val.getName());
				}
			}
			return "User/main.html";
		}
		
		return "/login/Before_login.html";
	}
}
