package TEST.Security_Cont;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import TEST.Controller.CS_cont;
import TEST.DAO.mapper;
import TEST.DTO.DTO_FieldValue;
import TEST.DTO.DTO_notice_value;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Configuration
@EnableWebSecurity
@Controller
public class Web_Cont {
	@Autowired
	private mapper ma;
	
	@RequestMapping("/login")
	public String login(HttpServletRequest Http_request){
		HttpSession Http_Session = Http_request.getSession(true); 
		String Session_value = String.valueOf(Math.random());
		Http_Session.setAttribute("Session", String.valueOf(Session_value)); //세션 생성
		
		return "/login/login_page.html";
	}
	
	@RequestMapping("/login/join")
	public String join(){
		return "/login/join_page.html";
	}
	
	@RequestMapping("/login/find")
	public String Find_id_pw() {
		return "/login/Find_id_pw.html";
	}
	
	
	@RequestMapping("/main/notice_board")
	public String notice_board(Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
			}
		}
		
		Iterator<DTO_notice_value> its = ma.DB_notice_Select().iterator();
		mo.addAttribute("notice_data", its);
		
		return "User/notice_board.html";
	}
	
	@PostMapping("admin/god")
	public String admin() {
		return "/Admin/admin_site.html";
	}
}