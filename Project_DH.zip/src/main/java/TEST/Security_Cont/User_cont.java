package TEST.Security_Cont;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;

public class User_cont {
	
	    public String getUser(Model model) {
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	        model.addAttribute("username", authentication.getName());
	        return "user";
	        }
	
}
