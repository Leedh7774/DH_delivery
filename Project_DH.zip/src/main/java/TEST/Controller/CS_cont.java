package TEST.Controller;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

public class CS_cont {
	public boolean Compare_Cookie_Session(HttpServletRequest Http_request) { // 쿠키와 세션 비교 반환값 : (true : false)
		HttpSession Sn = Http_request.getSession(true); //세션 적재[false = 없으면 null 적재]
		Cookie []coo = Http_request.getCookies();
		HttpSession Http_Session = Http_request.getSession(false);
		if(coo != null && Http_Session != null) {
			for(Cookie Cookies : coo) {
				if(Cookies.getValue().equals(Http_Session.getAttribute("Session"))) {
					return true;
				}
			}
		}
		Sn.invalidate(); 
		return false;
	}
	
}
