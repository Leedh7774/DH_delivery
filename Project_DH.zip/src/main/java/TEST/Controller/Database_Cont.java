package TEST.Controller;

import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import TEST.DAO.mapper;
import TEST.DTO.DTO_FieldValue;
import TEST.DTO.DTO_builder;
import TEST.DTO.DTO_food_value;
import TEST.DTO.DTO_notice_content_value;
import TEST.DTO.DTO_notice_value;
import TEST.DTO.DTO_read_notice;
import TEST.DTO.DTO_world_value;
import TEST.Security_Cont.Secure_Config;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class Database_Cont {
	DTO_read_notice r_notice = new DTO_read_notice();
	@Autowired
	private mapper ma;
	
	@PostMapping("/login/find_id")
	public String find_id(@RequestParam(name="NAME") String name,
			@RequestParam(name="SN_1") String sn_1,
			@RequestParam(name="SN_2") String sn_2, Model mo) {
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		while(it.hasNext())
		{
			DTO_FieldValue d_val = it.next();
			if(d_val.getName().equals(name) && d_val.getS_1().equals(sn_1) && d_val.getS_2().equals(sn_2)) {
				mo.addAttribute("getid", d_val.getId());
			}
		}	
		return "/login/Find_id_pw.html";
	}
	@PostMapping("/login/find_pw")
	public String find_pw(@RequestParam(name="SN_1") String sn_1,
			@RequestParam(name="SN_2") String sn_2,
			@RequestParam(name="ID") String id, Model mo) {
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		while(it.hasNext())
		{
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(id) && d_val.getS_1().equals(sn_1) && d_val.getS_2().equals(sn_2)) {
				mo.addAttribute("getpw", d_val.getPw());
			}
		}	
		return "/login/Find_id_pw.html";
	}
	
	@GetMapping("/main/in_notice_board")
	public String in_notice_board(@RequestParam("data_NAME") String data_NAME,
								  @RequestParam("data_TITLE") String data_TITLE, 
								  @RequestParam("data_ID") String data_ID, Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
			}
		}
		
		Iterator<DTO_notice_value> its = ma.DB_notice_Select().iterator(); //게시판 글 
		while(its.hasNext()) {
			DTO_notice_value  d_val = its.next();
			if(d_val.getName().equals(data_NAME) && d_val.getTitle().equals(data_TITLE)) {
				mo.addAttribute("notice_name", d_val.getName());
				r_notice.setOld_name(d_val.getName());
				mo.addAttribute("notice_title", d_val.getTitle());
				r_notice.setOld_title(d_val.getTitle());
				mo.addAttribute("notice_writing", d_val.getWriting());
				r_notice.setOld_writing(d_val.getWriting());
				r_notice.setUser_id(d_val.getId());
				if(auth.getName().equals(d_val.getId())) {
					mo.addAttribute("Writer", true);
				}
			}	
		}
		
		ArrayList<DTO_notice_content_value> notice_content = new ArrayList<>();
		
		Iterator<DTO_notice_content_value> it_notice = ma.DB_notice_content_Select().iterator(); // Database 적재된 내용들 확인
		while(it_notice.hasNext()) {
			DTO_notice_content_value d_val = it_notice.next();
			if(d_val.getTarget_id().equals(r_notice.getUser_id()) && d_val.getTarget_title().equals(r_notice.getOld_title())){
				notice_content.add(d_val);
			}
		}
		mo.addAttribute("notice_content", notice_content);
		

		return  "User/in_notice_board.html";
	}
	
	@PostMapping("main/content")
	public String add_notice_content(@RequestParam(name="content") String content, Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
				ma.DB_notice_content_Insert(auth.getName(), d_val.getName(), r_notice.getUser_id(), r_notice.getOld_title(), content);
				if(auth.getName().equals(d_val.getId())) {
					mo.addAttribute("Writer", true);
				}
			}
		}
		mo.addAttribute("notice_name", r_notice.getOld_name());
		mo.addAttribute("notice_title", r_notice.getOld_title());
		mo.addAttribute("notice_writing", r_notice.getOld_writing());
		ArrayList<DTO_notice_content_value> notice_content = new ArrayList<>();
		
		Iterator<DTO_notice_content_value> its = ma.DB_notice_content_Select().iterator(); // Database 적재된 내용들 확인
		while(its.hasNext()) {
			DTO_notice_content_value d_val = its.next();
			if(d_val.getTarget_id().equals(r_notice.getUser_id()) && d_val.getTarget_title().equals(r_notice.getOld_title())){
				notice_content.add(d_val);
			}
		}
		mo.addAttribute("notice_content", notice_content);
		
		return  "User/in_notice_board.html";
	}
	String Select_content_id, Select_content_writing;
	@RequestMapping("main/content_select")
	public String content_delete(@RequestParam("data_content_id") String data_content_id,
								 @RequestParam("data_content_writing") String data_content_writing, Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
				if(auth.getName().equals(d_val.getId())) {
					mo.addAttribute("Writer", true);
				}
			}
		}
		Select_content_id = data_content_id;
		Select_content_writing = data_content_writing;
		mo.addAttribute("Selec_id", Select_content_id);
		
		mo.addAttribute("notice_name", r_notice.getOld_name());
		mo.addAttribute("user_id", auth.getName());
		mo.addAttribute("notice_title", r_notice.getOld_title());
		mo.addAttribute("notice_writing", r_notice.getOld_writing());
		ArrayList<DTO_notice_content_value> notice_content = new ArrayList<>();
		
		Iterator<DTO_notice_content_value> its = ma.DB_notice_content_Select().iterator(); // Database 적재된 내용들 확인
		while(its.hasNext()) {
			DTO_notice_content_value d_val = its.next();
			
			if(d_val.getTarget_id().equals(r_notice.getUser_id()) && d_val.getTarget_title().equals(r_notice.getOld_title())){
				notice_content.add(d_val);
			}
		}
		mo.addAttribute("notice_content", notice_content);
		
		return "User/in_notice_board.html";
	}
	
	@PostMapping("main/content_delete")
	public String content_delete(Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
				if(auth.getName().equals(d_val.getId())) {
					mo.addAttribute("Writer", true);
				}
			}
		}
		
		ma.DB_notice_content_Delete(Select_content_id, Select_content_writing);
		
		mo.addAttribute("notice_name", r_notice.getOld_name());
		mo.addAttribute("user_id", auth.getName());
		mo.addAttribute("notice_title", r_notice.getOld_title());
		mo.addAttribute("notice_writing", r_notice.getOld_writing());
		ArrayList<DTO_notice_content_value> notice_content = new ArrayList<>();
		
		Iterator<DTO_notice_content_value> its = ma.DB_notice_content_Select().iterator(); // Database 적재된 내용들 확인
		while(its.hasNext()) {
			DTO_notice_content_value d_val = its.next();
			
			if(d_val.getTarget_id().equals(r_notice.getUser_id()) && d_val.getTarget_title().equals(r_notice.getOld_title())){
				notice_content.add(d_val);
			}
		}
		mo.addAttribute("notice_content", notice_content);
		
		return "User/in_notice_board.html";
	}
	
	
	@PostMapping("main/create_notice")
	public String create_notice(@RequestParam(name="notice_title") String title,
								@RequestParam(name="notice_writing") String writing, Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		String writing_name ="Error";
		
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				writing_name = d_val.getName();
				mo.addAttribute("user", d_val.getName());
			}
		}
		
		ma.DB_notice_Insert(auth.getName(), writing_name, title, writing);
		
		Iterator<DTO_notice_value> its = ma.DB_notice_Select().iterator();
		mo.addAttribute("notice_data", its);
		
		return "User/notice_board.html";
	}
	
	@PostMapping("main/notice_modify")
	public String notice_modify(Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
			}
		}
		
		mo.addAttribute("old_title", r_notice.getOld_title());
		mo.addAttribute("old_writing", r_notice.getOld_writing());
		
		Iterator<DTO_notice_value> its = ma.DB_notice_Select().iterator();
		while(its.hasNext()) {
			DTO_notice_value  d_val = its.next();
			if(d_val.getId().equals(auth.getName()) && d_val.getTitle().equals(r_notice.getOld_title())) {
				mo.addAttribute("notice_title", d_val.getTitle());
				mo.addAttribute("notice_writing", d_val.getWriting());
				break;
			}	
		}
		return "User/update_notice.html";
	}
	
	@PostMapping("main/update_notice")
	public String update_notice(@RequestParam(name="notice_title") String title,
								@RequestParam(name="notice_writing") String writing, Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
			}
		}
		
		ma.DB_notice_Update(title, writing, auth.getName(), r_notice.getOld_title());
		
		Iterator<DTO_notice_value> its = ma.DB_notice_Select().iterator();
		mo.addAttribute("notice_data", its);
		
		return "User/notice_board.html";
	}
	
	@PostMapping("main/notice_delete")
	public String notice_delete( Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
			}
		}
		
		ma.DB_notice_Delete(auth.getName(), r_notice.getOld_title());
		
		Iterator<DTO_notice_value> its = ma.DB_notice_Select().iterator();
		mo.addAttribute("notice_data", its);
		
		return "User/notice_board.html";
	}
	
	@PostMapping("/login/check")
	public String check(@RequestParam(name="ID") String id, Model mo) {
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(id)) {
				mo.addAttribute("bool", true);
				return "/login/join_page.html";
			}
		}
		mo.addAttribute("bool", false);
		mo.addAttribute("permit_id", id);
		return "/login/join_page.html";
	}	
	
	@PostMapping("/admin/user_info")
	public String user_info(Model mo) {
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		mo.addAttribute("user_info", it);
		return "Admin/admin_site.html";
	}
	@PostMapping("/admin/notice")
	public String admin_notice(Model mo) {
		Iterator<DTO_notice_value> it = ma.DB_notice_Select().iterator();
		mo.addAttribute("notice_data", it);
		return "Admin/admin_site.html";
	}
	@PostMapping("/admin/delete")
	public String admin_notice_delete(@RequestParam("id") String id,
									  @RequestParam("title") String title, Model mo) {
		Iterator<DTO_notice_value> it = ma.DB_notice_Select().iterator();
		while(it.hasNext()) {
			DTO_notice_value d_val = it.next();
			if(d_val.getId().equals(id) && d_val.getTitle().equals(title)) {
				ma.DB_notice_Delete(id, title);
			}
		}
		mo.addAttribute("notice_data", it);
		
		return "Admin/admin_site.html";
	}
	
	@PostMapping("/admin/food_info")
	public String admin_food_info(@RequestParam(name="world_data") String world_data, Model mo) {
		if(world_data.equals("한 식")) {
			Iterator<DTO_food_value> it_KO = ma.DB_KOREAN_Select().iterator();
			mo.addAttribute("KOREAN_FOOD", it_KO);
		}
		if(world_data.equals("중 식")) {
			Iterator<DTO_food_value> it_CH = ma.DB_CHINESE_Select().iterator();
			mo.addAttribute("CHINESE_FOOD", it_CH);
		}
		if(world_data.equals("일 식")) {
			Iterator<DTO_food_value> it_JP = ma.DB_JAPANESE_Select().iterator();
			mo.addAttribute("JAPANESE_FOOD", it_JP);
		}
		if(world_data.equals("양 식")) {
			Iterator<DTO_food_value> it_WE = ma.DB_WESTERN_Select().iterator();
			mo.addAttribute("WESTERN_FOOD", it_WE);
		}
		return "Admin/admin_site.html";
	}
	
	@PostMapping("/admin/delete_food_ko")
	public String admin_delete_food_k(@RequestParam("food_id") String food_id, Model mo) {
		Iterator<DTO_food_value> it = ma.DB_KOREAN_Select().iterator();
		while(it.hasNext()) {
			DTO_food_value d_val = it.next();
			if(food_id.equals(d_val.getFood())) {
				ma.DB_Korean_food_delete(food_id);
			}
		}
		return "Admin/admin_site.html";
	}
	@PostMapping("/admin/delete_food_ch")
	public String admin_delete_food_c(@RequestParam("food_id") String food_id, Model mo) {
		Iterator<DTO_food_value> it = ma.DB_CHINESE_Select().iterator();
		while(it.hasNext()) {
			DTO_food_value d_val = it.next();
			if(food_id.equals(d_val.getFood())) {
				ma.DB_Chinese_food_delete(food_id);
			}
		}
		return "Admin/admin_site.html";
	}
	@PostMapping("/admin/delete_food_jp")
	public String admin_delete_food_j(@RequestParam("food_id") String food_id, Model mo) {
		Iterator<DTO_food_value> it = ma.DB_JAPANESE_Select().iterator();
		while(it.hasNext()) {
			DTO_food_value d_val = it.next();
			if(food_id.equals(d_val.getFood())) {
				ma.DB_Japanese_food_delete(food_id);
			}
		}
		return "Admin/admin_site.html";
	}
	@PostMapping("/admin/delete_food_we")
	public String admin_delete_food_w(@RequestParam("food_id") String food_id, Model mo) {
		Iterator<DTO_food_value> it = ma.DB_WESTERN_Select().iterator();
		while(it.hasNext()) {
			DTO_food_value d_val = it.next();
			if(food_id.equals(d_val.getFood())) {
				ma.DB_Western_food_delete(food_id);
			}
		}
		return "Admin/admin_site.html";
	}
	@PostMapping("/admin/insert_food")
	public String admin_insert_food(@RequestParam(name="world2_data") String world_data,
									@RequestParam(name="in_food") String in_food, Model mo) {
		if(world_data.equals("한 식")) {
			ma.DB_Korean_food_insert(in_food);
		}
		if(world_data.equals("중 식")) {
			ma.DB_Chinese_food_insert(in_food);
		}
		if(world_data.equals("일 식")) {
			ma.DB_Japanese_food_insert(in_food);
		}
		if(world_data.equals("양 식")) {
			ma.DB_Western_food_insert(in_food);
		}
		
		return "Admin/admin_site.html";
	}
	
	@RequestMapping("/main/world")
	public String world_site(Model mo) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
		Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
		while(it.hasNext()) {
			DTO_FieldValue d_val = it.next();
			if(d_val.getId().equals(auth.getName())) {
				mo.addAttribute("user", d_val.getName());
			}
		}
		Iterator<DTO_world_value> its = ma.DB_WORLD_Select().iterator();
		mo.addAttribute("world", its);
	
		return "User/food.html";
	}

		@RequestMapping("/main/food")
		public String food_site(@RequestParam("food") String food, Model mo) {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication(); //현재 인증된 user 검색
			Iterator<DTO_FieldValue> it = ma.DB_Select().iterator(); // Database 적재된 내용들 확인
			while(it.hasNext()) {
				DTO_FieldValue d_val = it.next();
				if(d_val.getId().equals(auth.getName())) {
					mo.addAttribute("user", d_val.getName());
				}
			}
			
			Iterator<DTO_world_value> its = ma.DB_WORLD_Select().iterator();
			mo.addAttribute("world", its);
		
			if(food.equals("KOREAN_FOOD")) {
				Iterator<DTO_food_value> it_KO = ma.DB_KOREAN_Select().iterator();
				mo.addAttribute("KOREAN_FOOD", it_KO);
			}
			if(food.equals("CHINESE_FOOD")) {
				Iterator<DTO_food_value> it_CH = ma.DB_CHINESE_Select().iterator();
				mo.addAttribute("CHINESE_FOOD", it_CH);
			}
			if(food.equals("JAPANESE_FOOD")) {
				Iterator<DTO_food_value> it_JP = ma.DB_JAPANESE_Select().iterator();
				mo.addAttribute("JAPANESE_FOOD", it_JP);
			}
			if(food.equals("WESTERN_FOOD")) {
				Iterator<DTO_food_value> it_WE = ma.DB_WESTERN_Select().iterator();
				mo.addAttribute("WESTERN_FOOD", it_WE);
			}
			
			return "User/food.html";
		}
	
}